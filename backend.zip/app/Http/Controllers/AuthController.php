<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\UserCode;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Controller;
use Illuminate\Auth\Events\Registered;
use Illuminate\Support\Facades\Validator;
use Symfony\Component\HttpFoundation\Response;
use Exception;
use Illuminate\Foundation\Auth\AuthenticatesUsers;

// importante para envio de sms
use Twilio\Rest\Client;

class AuthController extends Controller
{
    /**
     * Create a new AuthController instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth:api', ['except' => ['login', 'newRegistro','buscaCorreo',]]);
    }

    
    public function login(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required|email',
            'password' => 'required|string|min:8',
        ]);

        if ($validator->fails()) {
            return response()->json($validator->errors(), 422);
        }

        if (! $token = auth()->attempt($validator->validated())) {
            return response()->json(['error' => 'Unauthorized'], 401);
        }

        $user = auth()->user();
        if($user->email_verified_at == NULL){
            return response()->json(['message'=>'Email no verificado, Confirme su correo electrónico',
            'err'=>'err'],  Response::HTTP_NOT_FOUND);
        }
            

        // if (Auth::attempt($validated())) {
  
          
  
        //     return redirect()->route('2fa.index');
        // }
    
        // return redirect()
        // ->route('login')
        // ->with('error', 'You have entered invalid credentials');
        auth()->user()->generateCode();
        //   return response()->json(['message'=>'El usuario si existe'],201) ;

        return $this->createNewToken($token);


    }


    public function userProfile() {
        return response()->json(auth()->user());
    }

  
    public function logout()
    {
        // $this->guard()->logout();
        // return response()->json(['message' => 'Successfully logged out']);
        auth()->logout();
        return response()->json(['message' => 'El usuario cerró la sesión con éxito']);
    }

   
    public function refresh()
    {
        // return $this->respondWithToken($this->guard()->refresh());
        return $this->createNewToken(auth()->refresh());
    }

   
    protected function createNewToken($token){
        return response()->json([
            'access_token' => $token,
            'token_type' => 'bearer',
            'expires_in' => auth()->factory()->getTTL() * 60,
            'user' => auth()->user()
        ]);
    }


    public function guard()
    {
        return Auth::guard();
    }


    public function newRegistro(Request $request){
        $validator = Validator::make($request->all(), [
            'nombre' => 'required|string|between:2,100',
            'apellido' => 'required|string|between:2,100',
            // 'phone' => ['required', 'max:255', 'unique:users'],
            'email'   => 'required|string|email|max:100|unique:users',
            'password'  => 'required|string|min:8',
            // 'confirmPassword'  => 'required|string|min:8'
        ]);

        if ($validator->fails()) {
                return response()->json($validator->errors()->toJson(),400);
        }

        $user = User::create(array_merge(
            $validator->validate(), 
             ['password' => bcrypt($request->password)]
        ));

        event(new Registered($user));


        return response()->json([
            'message' =>'usuario registrado exitosamente!',
            'user' => $user
        ],201);

    }


    public function buscaCorreo($request){
       
        try{
            $user = User::where('email', $request)->first();
            // $user = User::find($request->route('correo'));

            // return response()->json(['correo'=>$user]);

            if($user['email'] != null){
                return response()->json([
                    'message' =>'El correo si existe!',
                    'user' => $user['email'] 
                ],201);
            }
            
          }catch(\Exception $e){
            return response()->json(['success' => false], 500);
          }


    }





/*
//    2fa sms
*/

    public function smsVerificar(Request $request)
    {

        if( auth()){
             
            // return response()->json(auth(),  200);
              $request->validate([
                        'code'=>'required',
                    ]);
            
                        try {
            
                            $find = UserCode::where('user_id', auth()->user()->id)
                            ->where('code', $request->code)
                            ->where('updated_at', '>=', now()->subMinutes(5))
                            ->first();

                            if (!is_null($find)) {
                                // Session::put('user_2fa', auth()->user()->id);
                                // return redirect()->route('home');
                                $token = auth()->refresh();
                                return $this->createNewToken($token);
                            }

                            return response()->json(['message'=>'Ingresaste un código  incorrecto.',
                                'err'=>'err'],  Response::HTTP_NOT_FOUND);

                        } catch (Exception $e) {
                        
                            info("Error: ". $e->getMessage());
                        }



        }else{
                
            return response()->json(['message'=>'No tienes acceso.',
            'err'=>'err'],  500);

        }
  





        // $validated = $request->validate([
        //     'code' => 'required',
        //     'email' => 'required|email'
        // ]);
        // // $userEmail = $request->input('email');
        // $userEmail =$validated['email'];
        // // $user = User::find($request->input('email'));
        // $user = User::where('email', $userEmail)->first();


        // // $user->email_verified_at == NULL

        // // $validator = Validator::make($request->all(), [
        // //     'email' => 'required|email',
        // //     'code' => 'required',
        // // ]);

        // 

        // // if ($validator->fails()) {
        // //     return response()->json($validator->errors(), 422);
        // // }

        // // if (! $token = auth()->attempt($validator->validated())) {
        // //     return response()->json(['error' => 'Unauthorized'], 401);
        // // }


        // $exists = UserCode::where('user_id', $user->id)
        //         ->where('code', $validated['code'])
        //         ->where('updated_at', '>=', now()->subMinutes(5))
        //         ->exists();

        // if ($exists) {
        //     // si el codigo es valido puede iniciar sesion
        //     // \Session::put('tfa', auth()->user()->id);
        //     // auth()->user()->id;
        //     // return redirect()->route('home');
        //     ! $token = auth()->attempt();
        //     return $this->createNewToken($token);
        // }


        
        // return response()->json(['message'=>'Ingresaste un código OTP incorrecto.',
        //     'err'=>'err'],  Response::HTTP_NOT_FOUND);
    }


    // public function resendSMS()
    // {
    //     // auth()->user()->generateCode();
    //     $this->generateCode();
    //     return back()
    //         ->with('success', 'Hemos reenviado el código en su número de móvil.');
    // }


 

}
