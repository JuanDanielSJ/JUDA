<?php

namespace App\Http\Controllers\API;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
Use App\Models\ProductosVendidos;

class ProductosVendidosController extends Controller
{
    public function getAll(){
        $data = ProductosVendidos::get();
        return response()->json($data, 200);
      }
  
    public function create(Request $request){
      
        foreach ($request->all() as $items) {
            ProductosVendidos::create([
              'precio' => $items['precio'],
              'cantidad' => $items['cantidad'],
              'imagen' => $items['imagen'],
              'usuario_id' => auth()->user()->id,
              'producto_id' => $items['id']
            ]);
       }
      return response()->json([
        'message' => "Successfully created",
        'success' => true
     ], 200);
   
    }


    public function get(){
     
      try{

        $existe = DB::table('productos_vendidos')->where('usuario_id', auth()->user()->id)->exists();

        if($existe){
          $data =  DB::table('productos_vendidos')->where('usuario_id',  auth()->user()->id)->get();
          return response()->json($data, 200);
        }

         return response()->json([
           'message' => "No hay datos",
       ], 404);
       }catch(\Exception $e){
         return response()->json(['success' => false], 500);
       }




    }

    
}
