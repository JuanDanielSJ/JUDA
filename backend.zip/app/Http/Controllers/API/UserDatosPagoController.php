<?php

namespace App\Http\Controllers\API;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
Use App\Models\UserDatosPago;

class UserDatosPagoController extends Controller
{
   
    public function getAll(){
        $data = UserDatosPago::get();
        return response()->json($data, 200);
      }
  
      public function create(Request $request){
        

        $data['nombre'] = $request['nombre'];
        $data['pais'] = $request['pais'];
        $data['estado'] = $request['estado'];
        $data['codigoPostal'] = $request['codigoPostal'];
        $data['direccion'] = $request['direccion'];
        $data['usuario_id'] = auth()->user()->id;
     

        // return response()->json([
        //             'message' => $data,
        //             'success' => true
        //         ], 200);
        
               UserDatosPago::create($data);
            return response()->json([
                'message' => "Successfully created",
                'success' => true
            ], 200);


        // $existeProducto = DB::table('producto')->where('id', $request['producto_id'])->exists();
        // $existeUser = DB::table('users')->where('id', $request['usuario_id'])->exists();
        
        
        // if($existeProducto &&  $existeUser){
    
        //   }
        
        //   return response()->json([
        //     'message' => "Hubo un error",
        //     'success' => false
        // ], 404);
    }


}
