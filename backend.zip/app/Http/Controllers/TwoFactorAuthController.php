<?php

namespace App\Http\Controllers;

use App\Models\UserCode;
use App\Models\User;
use Illuminate\Http\Request;
use Session;

class TwoFactorAuthController extends Controller
{
    
    
    // public function index()
    // {
    //     return view('2fa');
    // }

   
    // public function store(Request $request)
    // {
    //     $validated = $request->validate([
    //         'code' => 'required',
    //     ]);
  
    //     $exists = UserCode::where('user_id', auth()->user()->id)
    //             ->where('code', $validated['code'])
    //             ->where('updated_at', '>=', now()->subMinutes(5))
    //             ->exists();
  
    //     if ($exists) {
    //         // si el codigo es valido puede iniciar sesion
    //         \Session::put('tfa', auth()->user()->id);
            
    //         return redirect()->route('home');
    //     }
  
    //     return redirect()
    //         ->back()
    //         ->with('error', 'Ingresaste un código OTP incorrecto.');
    // }
   
    // public function resend()
    // {
    //     auth()->user()->generateCode();
  
    //     return back()
    //         ->with('success', 'Hemos reenviado el código en su número de móvil.');
    // }
}
