<?php



namespace App\Http\Controllers;

use Illuminate\Auth\Events\Verified;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Models\User;

use Illuminate\Routing\Exceptions\InvalidSignatureException;
// use Illuminate\Auth\Access\AuthorizationException;
// use Illuminate\Foundation\Auth\VerifiesEmails;

class VerifyEmailController extends Controller
{

//    public 

    public function __invoke(Request $request): RedirectResponse
    {
        $urlFrontEnd  ='https://modasjenl.com/#';
        
        $user = User::find($request->route('id'));
        // $userEmail = $request->input('email');
        // $user = User::find($request->input('email'));
        // $userEmail = User::where('email', $userEmail)->first();


          // el email se ha confirmado anteriormente
        if ($user->hasVerifiedEmail()) {
            // return redirect(env('http://localhost:4200/#') . '/email/verify/already-success');
            return redirect('https://modasjenl.com/#' . '/email/verify/already-success/'.$user['email']);
        }

        if ($user->markEmailAsVerified()) {
            event(new Verified($user));
        }else {
            // return redirect('https://www.google.com');
        }


        if(!$request->hasValidSignature()) {
            // some custom message
            // return redirect('https://www.google.com');
            // abort(401);
            $this->renderable(function (InvalidSignatureException $e) {
                // return response()->view('error.link-expired', [], 403);
                return redirect('https://www.google.com');
            });
    
        }
       
        



        // el email se ha confirmado
        // return redirect(env('http://localhost:4200/#') . '/email/verify/success');
        return redirect('https://modasjenl.com/#'  . '/email/verify/success/'.$user['email']);
    }


/**
* Resend the email verification notification.
*/

    public function resend(Request $request)
    {
        // $urlFrontEnd  ='http://localhost:4200/#';
        $userEmail = $request->input('email');
        // $user = User::find($request->input('email'));
        $user = User::where('email', $userEmail)->first();

        // $data =  Producto::where('categoria_id','=',$idcategoria)->get();
        // return response()->json($user,201);
        
        if ($user->hasVerifiedEmail()) {
            return response()->json(['message'=>'¡El usuario ya tiene correo electrónico verificado!', 422]);
            // return redirect($this->redirectPath());
        }

        $user->sendEmailVerificationNotification();
        return response()->json(['message'=>'La notificación ha sido reenviada',201]);
        // return back()->with(‘resent’, true);
    }



   





    //  public function verify(Request $request)
    // {
    //     try {
    //         return $this->verifyTrait($request);
    //     } catch (AuthorizationException $e) {
    //         return redirect('https://www.google.com'); // what ever you would like to do on failure
    //     }
    // }


}