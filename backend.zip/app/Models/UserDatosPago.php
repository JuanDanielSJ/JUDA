<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UserDatosPago extends Model
{
    use HasFactory;

    protected $table = "user_datos_pagos";

    protected $fillable = [
      'nombre',
      'pais',
      'estado',
      'codigoPostal',
      'direccion',
      'usuario_id'
    ];
}
