<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ProductosVendidos extends Model
{
    use HasFactory;

    protected $table = "productos_vendidos";

    protected $fillable = [
      'precio',
      'cantidad',
      'imagen',
      'usuario_id',
      'producto_id'
    ];

}
