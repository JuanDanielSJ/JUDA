<!DOCTYPE html>
<html>
<head>
    <title>Yoyomitl H</title>
</head>
<body>
    <h3>{{ $details['title'] }}</h3>
    <p ;">Tu código es : <h2><center> {{ $details['code'] }} </h3> </center> </p>
            <p>
            <br>
            El código expirará en 5 minutos. No compartas este código
            <br>
            Gracias!!
            </p>
</body>
</html>