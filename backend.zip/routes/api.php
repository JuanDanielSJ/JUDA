<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use Illuminate\Foundation\Auth\EmailVerificationRequest;
use App\Http\Controllers\API\ProductoController;
use App\Http\Controllers\API\CategoriaController;
use App\Http\Controllers\API\ProductosVendidosController;
use App\Http\Controllers\API\UserDatosPagoController;
use App\Http\Controllers\PasswordResetRequestController;
use App\Http\Controllers\ChangePasswordController;
use App\Http\Controllers\VerifyEmailController;

use App\Http\Controllers\TwoFactorAuthController;
/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

// Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
//     return $request->user();
// });

Route::prefix('producto')->group(function () {
    Route::get('/',[ ProductoController::class, 'getAll']);
    Route::post('/',[ ProductoController::class, 'create']);
    Route::delete('/{id}',[ ProductoController::class, 'delete']);
    Route::get('/{id}',[ ProductoController::class, 'get']);
    Route::put('/{id}',[ ProductoController::class, 'update']);
    Route::get('/user/{id}',[ ProductoController::class, 'getProductosUsert']);
    Route::get('/categoria/{idcategoria}',[ ProductoController::class, 'getproductocategoria']);
});



Route::group([
    'middleware' => 'api',
    'namespace' => 'App\Http\Controllers',
    'prefix' => 'auth'
], function ($router) {
    Route::post('login', 'AuthController@login');
    Route::post('logout', 'AuthController@logout');
    Route::post('refresh', 'AuthController@refresh');
    Route::post('user-profile', 'AuthController@userProfile');
    Route::post('newRegistro', 'AuthController@newRegistro');

    Route::get('/{email}', 'AuthController@buscaCorreo');

    Route::post('/reset-password-request', [PasswordResetRequestController::class, 'sendPasswordResetEmail']);
    Route::post('/change-password', [ChangePasswordController::class, 'passwordResetProcess']);

    Route::post('smsverificar', [AuthController::class, 'smsVerificar']);
    Route::get('two-factor-auth/resent', [AuthController::class, 'resendSMS']);
});




Route::prefix('categoria')->group(function () {
    Route::get('/',[ CategoriaController::class, 'getAll']);
    Route::post('/',[ CategoriaController::class, 'create']);
    Route::delete('/{id}',[ CategoriaController::class, 'delete']);
    Route::get('/{id}',[ CategoriaController::class, 'get']);
    Route::put('/{id}',[ CategoriaController::class, 'update']);
});

Route::prefix('productosvendidos')->group(function () {
    Route::get('/',[ ProductosVendidosController::class, 'getAll']);
    Route::post('/',[ ProductosVendidosController::class, 'create']);
    // Route::delete('/{id}',[ CategoriaController::class, 'delete']);
    Route::get('/user',[ ProductosVendidosController::class, 'get']);
    // Route::put('/{id}',[ CategoriaController::class, 'update']);
});
Route::prefix('datospago')->group(function () {
    Route::get('/',[ UserDatosPagoController::class, 'getAll']);
    Route::post('/',[ UserDatosPagoController::class, 'create']);
    // Route::delete('/{id}',[ CategoriaController::class, 'delete']);
    // Route::get('/{id}',[ CategoriaController::class, 'get']);
    // Route::put('/{id}',[ CategoriaController::class, 'update']);
});


// Verify email
Route::get('/email/verify/{id}/{hash}', [VerifyEmailController::class, '__invoke'])
    ->middleware(['signed', 'throttle:6,1'])
    ->name('verification.verify');

// Reenviar enlace para verificar el correo electrónico
// Route::post('/email/verify/resend', function (Request $request) {
//     $request->user()->sendEmailVerificationNotification();
//     return back()->with('message', 'Enlace de verificación enviado!');
// })->middleware(['auth:api', 'throttle:6,1'])->name('verification.send');

Route::post('/email/verify/resend', [VerifyEmailController::class, 'resend'])
    // ->middleware(['auth:api', 'throttle:6,1'])
    ->name('verification.send');

    

    Route::get('two-factor-auth', [TwoFactorAuthController::class, 'index'])->name('2fa.index');

    // Route::post('smsverificar', [TwoFactorAuthController::class, 'smsVerificar'])->name('2fa.store');
    // Route::get('two-factor-auth/resent', [TwoFactorAuthController::class, 'resendSMS'])->name('2fa.resend');
