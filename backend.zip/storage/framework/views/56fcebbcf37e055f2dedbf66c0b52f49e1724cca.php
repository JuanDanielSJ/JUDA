<!-- # Restablecer contraseña

Restablece o cambia tu contraseña..

<?php $__env->startComponent('mail::button', ['url' => 'http://localhost:4200/change-password?token='.$token]); ?>
Cambia la contraseña
<?php echo $__env->renderComponent(); ?>

Gracias,<br>
Modas JENL -->

<!DOCTYPE html>
    <html lang="en">
    
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    
        <title>modasjenl.com</title>
    </head>
    
    <body>
  
        <div class="container">
            <div style=" background-color:#ff4081; margin-top:30px ;justify-content: center; ">
    
                <div style=" height:50px ; display: flex;">
                    <img src="https://modasjenl.com/assets/logo.gpeg" width="50px" style="margin-left: 20px;">
                    <label style="color:#fff; font-weight: bolder; margin:9px; font-size:25px;"> Moda y estilo JENL</label>
                </div>
    
    
    
    
                <div style="  height:auto ;  background-color:#fff; margin:5px 10px 5px 10px">
                    <div class="container" >
                        <h3 style="margin: 10px;" >
                        Restablece o cambia tu contraseña..
                        </h3>
                        <br>
                        
                        <div style="  height:auto ;  background-color:#fff; margin:0 10px 5px 10px;text-align: justify;">
                        <p>
                               Has recibido este mensaje porque has solicitado cambiar la contraseña de tu cuenta de MODAS JENL.
                        </p><br><br>

                        <p>
                                  Para cambiar la contraseña, DA Click en cambiar contraseña:
                        </p><br>
                        <?php $__env->startComponent('mail::button', ['url' => 'http://localhost:4200/#/change-password?token='.$token]); ?> 
                            Cambia la contraseña
                        <?php echo $__env->renderComponent(); ?>
                        <span style="color:#000000;font-size:15px;font-weight:400;line-height:inherit;text-decoration:inherit;font-family:arial,helvetica,sans;font-style:normal;margin: 10px;">
                           
                            </span>
                            <br>
                            Gracias,<br>
                        Modas JENL
                        </div>
                        <br><br>
                        <center>
                        </center>
                        <br><br><br>
                    </div>
                </div>
                <footer class="text-center text-lg-start bg-light text-muted">
                <center>
                    <div class="text-center p-4" style="background-color: rgba(0, 0, 0, 0.05);">
                        2021 Copyright:
                        <a class="text-reset fw-bold" href="https://modasjenl.com/">modasjenl.com</a>
                    </div>
                    </center>
                </footer>
    
            </div>
    
        </div>
    
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    
    <?php /**PATH C:\xampp\htdocs\8vo\modasjenlp2\backend\resources\views/Email/resetPassword.blade.php ENDPATH**/ ?>