<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\8vo\modasjenlp2\backend\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>